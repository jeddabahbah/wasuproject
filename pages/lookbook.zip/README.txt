A Pen created at CodePen.io. You can find this one at http://codepen.io/mariosmaselli/pen/WGwKVg.

 Exploring a slider concept designed by @Logancee https://dribbble.com/logancee