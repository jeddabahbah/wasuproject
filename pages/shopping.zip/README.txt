A Pen created at CodePen.io. You can find this one at http://codepen.io/littlesnippets/pen/jqEajG.

 Shopping card with footer cart icon.