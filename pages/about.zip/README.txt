A Pen created at CodePen.io. You can find this one at http://codepen.io/notbigmuzzy/pen/qOKreX.

 Just saw this ( www.behance.net/gallery/30024827/Menu-from-the-world  ) and had to recreate it because it's so awesome.  This is just a CODE PRACTICE,  all the idea & design credits go to this guy www.behance.net/aureliensalomon